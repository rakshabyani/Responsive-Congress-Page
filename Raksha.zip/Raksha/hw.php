<?php

	$rawData = json_decode(file_get_contents("php://input"));
    
    if(isset($rawData->bioguide_id)){
    	
    	$bioguide = $rawData->bioguide_id;
        
        $committee = "http://congress.api.sunlightfoundation.com/committees?chamber=senate&member_ids=".$bioguide."&apikey=ad72ce0451nc64d1c83417410a624c96c";
    	$json_committee = file_get_contents($committee);
        
    	$bill = "http://congress.api.sunlightfoundation.com/bills?sponsor_id=".$bioguide."&apikey=ad72ce0451nc64d1c83417410a624c96c";
    	$json_bill = file_get_contents($bill);

    	$json_info = array($json_committee, $json_bill);
       
    	echo json_encode($json_info);
    }
    else {
        

	$startUrl_leg = "http://congress.api.sunlightfoundation.com/legislators?apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=all";
		$json_info_leg = file_get_contents($startUrl_leg);

	$startUrl_leg_house = "http://congress.api.sunlightfoundation.com/legislators?chamber=house&apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=all";
		$json_info_leg_house = file_get_contents($startUrl_leg_house);

	$startUrl_leg_senate = "http://congress.api.sunlightfoundation.com/legislators?chamber=senate&apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=all";
		$json_info_leg_senate = file_get_contents($startUrl_leg_senate);
	
	$startUrl_active_bill = "https://congress.api.sunlightfoundation.com/bills?history.active=true&apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=50";
		$json_info_active_bill = file_get_contents($startUrl_active_bill);
        
    $startUrl_new_bill = "https://congress.api.sunlightfoundation.com/bills?history.active=false&apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=50";
		$json_info_new_bill = file_get_contents($startUrl_new_bill);

	$startUrl_committee = "https://congress.api.sunlightfoundation.com/committees?chamber=house&apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=all";
		$json_info_committee_h = file_get_contents($startUrl_committee);
	$startUrl_committee = "https://congress.api.sunlightfoundation.com/committees?chamber=senate&apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=all";
		$json_info_committee_s = file_get_contents($startUrl_committee);
	$startUrl_committee = "https://congress.api.sunlightfoundation.com/committees?chamber=joint&apikey=ad72ce0451nc64d1c83417410a624c96c&per_page=all";
		$json_info_committee_j = file_get_contents($startUrl_committee);

	$json_info = array($json_info_leg, $json_info_leg_house, $json_info_leg_senate, $json_info_active_bill, $json_info_new_bill, $json_info_committee_h, $json_info_committee_s, $json_info_committee_j);
	
    echo json_encode($json_info);    
    //echo "Hello PHP";

    }
?>

            
