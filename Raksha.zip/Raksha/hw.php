<?php

	$rawData = json_decode(file_get_contents("php://input"));
    
    if(isset($rawData->bioguide_id)){
    	
    	$bioguide = $rawData->bioguide_id;
    	$bill = "http://congress.api.sunlightfoundation.com/bills?sponsor_id=".$bioguide."&apikey=dc64b50ea0094b8794a3a8d96db12f86";
    	$json_bill = file_get_contents($bill);

    	$committee = "http://congress.api.sunlightfoundation.com/committees?chamber=senate&member_ids=".$bioguide."&apikey=dc64b50ea0094b8794a3a8d96db12f86";
    	$json_committee = file_get_contents($committee);

    	$json_info = array($json_committee, $json_bill);
       
    	echo json_encode($json_info);
    }
    else {
        

	$startUrl_leg = "http://congress.api.sunlightfoundation.com/legislators?apikey=dc64b50ea0094b8794a3a8d96db12f86&per_page=all";
		$json_info_leg = file_get_contents($startUrl_leg);

	$startUrl_leg_house = "http://congress.api.sunlightfoundation.com/legislators?chamber=house&apikey=dc64b50ea0094b8794a3a8d96db12f86&per_page=all";
		$json_info_leg_house = file_get_contents($startUrl_leg_house);

	$startUrl_leg_senate = "http://congress.api.sunlightfoundation.com/legislators?chamber=senate&apikey=dc64b50ea0094b8794a3a8d96db12f86&per_page=all";
		$json_info_leg_senate = file_get_contents($startUrl_leg_senate);
	
	$startUrl_bill = "https://congress.api.sunlightfoundation.com/bills?apikey=dc64b50ea0094b8794a3a8d96db12f86&per_page=50";
		$json_info_bill = file_get_contents($startUrl_bill);

	$startUrl_committee = "https://congress.api.sunlightfoundation.com/committees?chamber=house&apikey=dc64b50ea0094b8794a3a8d96db12f86&per_page=all";
		$json_info_committee_h = file_get_contents($startUrl_committee);
	$startUrl_committee = "https://congress.api.sunlightfoundation.com/committees?chamber=senate&apikey=dc64b50ea0094b8794a3a8d96db12f86&per_page=all";
		$json_info_committee_s = file_get_contents($startUrl_committee);
	$startUrl_committee = "https://congress.api.sunlightfoundation.com/committees?chamber=joint&apikey=dc64b50ea0094b8794a3a8d96db12f86&per_page=all";
		$json_info_committee_j = file_get_contents($startUrl_committee);

	$json_info = array($json_info_leg, $json_info_leg_house, $json_info_leg_senate, $json_info_bill, $json_info_committee_h, $json_info_committee_s, $json_info_committee_j);
	
    echo json_encode($json_info);    
    //echo "Hello PHP";

    }
?>

            
