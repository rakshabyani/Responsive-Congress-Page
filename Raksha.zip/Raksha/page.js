/*jslint browser: true*/
/*jslint node: true */
/*global $, jQuery, alert*/



//document.getElementsByTagName("h1")[0].innerHTML = "Hello changed in JS";
$("document").ready(function () {
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("active");
    });


    $("#header").html("Changed in JQuery");
    $("#tester").click(function (e) {
        $("#header").html("Changed in JQuery");
    });
});


var app = angular.module('myApp', ['angularUtils.directives.dirPagination']);

app.controller('MainController', function ($scope, $http) {

    debugger;
    $scope.states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'District Of Columbia', 'Florida',
                  'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland', 'Massachusetts',
                  'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico', 'New York',
                  'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina', 'South Dakota',
                  'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'];
    $scope.tester = "Hello";
    $scope.currentPage = 1;
    $scope.pageSize = 10;

    $http({
        method: 'GET',
        url: 'hw.php',
    }).then(function (response) {
        console.log(response);
        var json_legislator = JSON.parse(response.data[0]);
        var json_legislator_house = JSON.parse(response.data[1]);
        var json_legislator_senate = JSON.parse(response.data[2]);
        //        var json_bill = JSON.parse(response.data[3]);
        //        var json_committee_house = JSON.parse(response.data[4]);
        //        var json_committee_senate = JSON.parse(response.data[5]);
        //        var json_committee_joint = JSON.parse(response.data[6]);
        $scope.party_house = "http://cs-server.usc.edu:45678/hw/hw8/images/r.png";
        $scope.party_senate = "http://cs-server.usc.edu:45678/hw/hw8/images/d.png";
        $scope.house = "http://cs-server.usc.edu:45678/hw/hw8/images/h.png";
        $scope.senate = "http://cs-server.usc.edu:45678/hw/hw8/images/s.svg";
        //        $scope.bills_display = json_bill.results;
        $scope.legislators = json_legislator.results;
        $scope.house_legislators = json_legislator_house.results;
        $scope.senate_legislators = json_legislator_senate.results;
        //        $scope.comms_house = json_committee_house.results;
        //        $scope.comms_house_len = json_committee_house.count;
        //        $scope.comms_senate = json_committee_senate.results;
        //        $scope.comms_senate_len = json_committee_senate.count;
        //        $scope.comms_joint = json_committee_joint.results;

    }, function (response) {
        // error code
    });

    $scope.view_details = function (chosen_legislator) {
        $scope.chosen_legislator = chosen_legislator;
        var title, firstName, lastName;
        if (chosen_legislator.title)
            title = chosen_legislator.title + ", ";
        else if (chosen_legislator.title === null)
            title = '';

        if (chosen_legislator.last_name)
            lastName = chosen_legislator.last_name + ", ";
        else if (chosen_legislator.last_name === null)
            lastName = '';
        
        if (chosen_legislator.first_name)
            firstName = chosen_legislator.first_name;
        else if (chosen_legislator.first_name === null)
            firstName = '';

        $scope.chosen_legislator_name = title + lastName + firstName;

        $scope.chosen_legislator_image = "https://theunitedstates.io/images/congress/original/" + chosen_legislator.bioguide_id + ".jpg";

        $scope.chosen_legislator_email = chosen_legislator.email;

        $scope.chosen_legislator_chamber = chosen_legislator.chamber;

        //        202-225-6205
        if (chosen_legislator.phone) {
            var chosen_legislator_phone = chosen_legislator.phone;
            $scope.chosen_legislator_phone = chosen_legislator_phone;
            $scope.phone = chosen_legislator_phone.replace("-", "");
        }


        if (chosen_legislator.office)
            $scope.office = chosen_legislator.office;
        else if (chosen_legislator.office === null)
            $scope.office = "N.A.";

        if (chosen_legislator.state)
            $scope.state = chosen_legislator.state_name;
        else if (chosen_legislator.state === null)
            $scope.state = "N.A";

        if (chosen_legislator.fax)
            $scope.fax = chosen_legislator.fax;

        if (chosen_legislator.party === "R") {
            $scope.chosen_legislator_partyImage = "r.png";
            $scope.chosen_legislator_partyName = "Republican";
        } else if (chosen_legislator.party === "D") {
            $scope.chosen_legislator_partyImage = "d.png";
            $scope.chosen_legislator_partyName = "Democrat";

        }
        
        if(chosen_legislator.term_start)
            $scope.start = chosen_legislator.term_start;
        else if(chosen_legislator.term_start === null)
            $scope.start = "Not Specified";
        
        if(chosen_legislator.term_end)
           $scope.end = chosen_legislator.term_end;
        else if(chosen_legislator.term_end === null)
            $scope.end = "Not specified";
            
        var now = new Date().getTime() / 1000;
        var start = new Date(chosen_legislator.term_start).getTime() / 1000;
        var end = new Date(chosen_legislator.term_end).getTime() / 1000;
        $scope.progress = parseInt((now - start) / (end - start) * 100);

        if (chosen_legislator.birthday)
            $scope.birthday = chosen_legislator.birthday;
        else if (chosen_legislator.birthday === null)
            $scope.birthday = "N.A.";

        $scope.twitter = "https://twitter.com/" + chosen_legislator.twitter;
        $scope.facebook = "https://www.facebook.com/" + chosen_legislator.facebook_id;
        $scope.website = chosen_legislator.website;


        //GET COMMITTEE AND BILL DATA
        var bioguide_id = chosen_legislator.bioguide_id;
        $http({
            method: 'POST',
            url: 'hw.php',
            data: {
                bioguide_id: bioguide_id
            }
        }).then(function (response) {
            // console.log(response);
            var json_legislator_comm = JSON.parse(response.data[0]);
            var json_legislator_bill = JSON.parse(response.data[1]);
            var leg_bill = [];
            var leg_comm = [];
            var i = 0;
            if (json_legislator_comm.count > 0) {
                i = 0;
                while (i < 5 && i < json_legislator_comm.count) {
                    leg_comm[i] = json_legislator_comm.results[i];
                    i++;
                }
            } else {
                leg_comm[0] = "N.A.";
            }

            if (json_legislator_bill.count > 0) {
                i = 0;
                while (i < 5 && i < json_legislator_bill) {
                    leg_bill[i] = json_legislator_bill.results[i];
                    i++;
                }
            } else {
                leg_bill[0] = "N.A.";
            }
            $scope.leg_comms = leg_comm;
            $scope.legs_bills = leg_bill;

        })
    };
    /*$(".view-details").click(function(){
        $("#carousel-leg").carousel("next");
    });*/
});



/*
  $scope.currentPage = 1;
  $scope.pageSize = 10;
  $scope.meals = [];

  var dishes = [
    'noodles',
    'sausage',
    'beans on toast',
    'cheeseburger',
    'battered mars bar',
    'crisp butty',
    'yorkshire pudding',
    'wiener schnitzel',
    'sauerkraut mit ei',
    'salad',
    'onion soup',
    'bak choi',
    'avacado maki'
  ];
  var sides = [
    'with chips',
    'a la king',
    'drizzled with cheese sauce',
    'with a side salad',
    'on toast',
    'with ketchup',
    'on a bed of cabbage',
    'wrapped in streaky bacon',
    'on a stick with cheese',
    'in pitta bread'
  ];
  for (var i = 1; i <= 100; i++) {
    var dish = dishes[Math.floor(Math.random() * dishes.length)];
    var side = sides[Math.floor(Math.random() * sides.length)];
    $scope.meals.push('meal ' + i + ': ' + dish + ' ' + side);
  }
  
  $scope.pageChangeHandler = function(num) {
      console.log('meals page changed to ' + num);
  };*/



app.controller('OtherController', function ($scope) {
    $scope.pageChangeHandler = function (num) {
        console.log('going to page ' + num);
    };
});

app.controller('NavBarController', function ($scope) {
    //if it's active, display the entire thing, else display only icons
});