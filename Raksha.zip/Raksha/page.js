/*jslint browser: true*/
/*jslint node: true */
/*global $, jQuery, alert*/



//document.getElementsByTagName("h1")[0].innerHTML = "Hello changed in JS";
$("document").ready(function () {
    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        if ($("#mySidenav").hasClass("active")) {
            $("#mySidenav").removeClass("active");
            $(".page-content-wrapper").css("marginLeft", "0px");
        } else {
            $("#mySidenav").addClass("active");
            if ($(document).width() < 480)
                $(".page-content-wrapper").css("marginLeft", "80px");
            else
                $(".page-content-wrapper").css("marginLeft", "150px");
        }

        //$("#mySidenav").toggleClass("active");

    });


    $("#header").html("Changed in JQuery");
    $("#tester").click(function (e) {
        $("#header").html("Changed in JQuery");
    });
});



var app = angular.module('myApp', ['angularUtils.directives.dirPagination']);

app.controller('MainController', function ($scope, $http) {

    $scope.show_leg = true;
    $scope.hide_leg = false;
    $scope.show_bill = false;
    $scope.hide_bill = true;
    $scope.show_comm = false;
    $scope.hide_comm = true;
    $scope.show_fav = false;
    $scope.hide_fav = true;

    $scope.show_bill_tab_fav = false;
    $scope.show_leg_tab_fav = true;

    $scope.show_legislators = function () {
        $scope.show_leg = true;
        $scope.show_bill = false;
        $scope.show_comm = false;
        $scope.show_fav = false;
        
        var leg;
        if(localStorage.getItem('FavList_Legislator_34853nROU')){
            var fav_legs = JSON.parse(localStorage.getItem('FavList_Legislator_34853nROU'));
            for(var i = 0; i< fav_legs.length; i++){
                for(var pos = 0; pos < $scope.legislators.length; pos++){
                    leg = $scope.legislators[pos];
                    if(leg.bioguide_id === fav_legs[i].bioguide_id) {
                        exists_in_fav = true;
                        $scope.legislators[pos].exists_in_fav = exists_in_fav;
                    }
                    else {
                         exists_in_fav = false;
                        $scope.legislators[pos].exists_in_fav = exists_in_fav;
                    }
                }
                for(var pos = 0; pos < $scope.house_legislators.length; pos++){
                    leg = $scope.house_legislators[pos];
                    if(leg.bioguide_id === fav_legs[i].bioguide_id) {
                        exists_in_fav = true;
                        $scope.house_legislators[pos].exists_in_fav = exists_in_fav;
                    }
                    else {
                         exists_in_fav = false;
                        $scope.house_legislators[pos].exists_in_fav = exists_in_fav;
                    }
                }
                for(var pos = 0; pos < $scope.senate_legislators.length; pos++){
                    leg = $scope.senate_legislators[pos];
                    if(leg.bioguide_id === fav_legs[i].bioguide_id) {
                        exists_in_fav = true;
                        $scope.senate_legislators[pos].exists_in_fav = exists_in_fav;
                    }
                    else {
                         exists_in_fav = false;
                        $scope.senate_legislators[pos].exists_in_fav = exists_in_fav;
                    }
                }
            }
        }
    }

    $scope.show_bills = function () {
        $scope.show_leg = false;
        $scope.show_bill = true;
        $scope.show_comm = false;
        $scope.show_fav = false;

        var bill;
        if (localStorage.getItem('FavList_Bill_34853nROU')) {
            var fav_bills = JSON.parse(localStorage.getItem('FavList_Bill_34853nROU'));
            for (var i = 0; i < fav_bills.length; i++) {
                for (var pos = 0; pos < $scope.active_bills.length; pos++) {
                    bill = $scope.active_bills[pos];
                    if (bill.bill_id === fav_bills[i].bill_id) {
                        exists_in_fav = true;
                        $scope.active_bills[pos].exists_in_fav = exists_in_fav;
                    } else {
                        exists_in_fav = false;
                        $scope.active_bills[pos].exists_in_fav = exists_in_fav;
                    }
                }
                for (var pos = 0; pos < $scope.new_bills.length; pos++) {
                    bill = $scope.new_bills[pos];
                    if (bill.bill_id === fav_bills[i].bill_id) {
                        exists_in_fav = true;
                        $scope.new_bills[pos].exists_in_fav = exists_in_fav;
                    } else {
                        exists_in_fav = false;
                        $scope.new_bills[pos].exists_in_fav = exists_in_fav;
                    }
                }

            }
        }
    }

    $scope.show_committees = function () {
        $scope.show_leg = false;
        $scope.show_bill = false;
        $scope.show_comm = true;
        $scope.show_fav = false;

        var comm;
        if (localStorage.getItem('FavList_Committees_34853nROU')) {
            var fav_comm = JSON.parse(localStorage.getItem('FavList_Committees_34853nROU'));
            for (var i = 0; i < fav_comm.length; i++) {
                for (var pos = 0; pos < $scope.comms_house.length; pos++) {
                    comm = $scope.comms_house[pos];
                    if (comm.committee_id === fav_comm[i].committee_id) {
                        exists_in_fav = true;
                        $scope.comms_house[pos].exists_in_fav = exists_in_fav;
                    } else {
                        exists_in_fav = false;
                        $scope.comms_house[pos].exists_in_fav = exists_in_fav;
                    }
                }
                for (var pos = 0; pos < $scope.comms_senate.length; pos++) {
                    comm = $scope.comms_senate[pos];
                    if (comm.committee_id === fav_comm[i].committee_id) {
                        exists_in_fav = true;
                        $scope.comms_senate[pos].exists_in_fav = exists_in_fav;
                    } else {
                        exists_in_fav = false;
                        $scope.comms_senate[pos].exists_in_fav = exists_in_fav;
                    }
                }
                for (var pos = 0; pos < $scope.comms_joint.length; pos++) {
                    comm = $scope.comms_joint[pos];
                    if (comm.committee_id === fav_comm[i].committee_id) {
                        exists_in_fav = true;
                        $scope.comms_joint[pos].exists_in_fav = exists_in_fav;
                    } else {
                        exists_in_fav = false;
                        $scope.comms_joint[pos].exists_in_fav = exists_in_fav;
                    }
                }
            }
        }

    }

    $scope.show_favorites = function () {
        $scope.show_leg = false;
        $scope.show_bill = false;
        $scope.show_comm = false;
        $scope.show_fav = true;

    }

    $scope.currentPage = 1;
    $scope.pageSize = 10;

    $http({
        method: 'GET',
        url: 'hw.php',
    }).then(function (response) {
        // console.log(response);
        var json_legislator = JSON.parse(response.data[0]);
        var json_legislator_house = JSON.parse(response.data[1]);
        var json_legislator_senate = JSON.parse(response.data[2]);

        var json_active_bill = JSON.parse(response.data[3]);
        $scope.active_bills = json_active_bill.results;
        var json_new_bill = JSON.parse(response.data[4]);
        $scope.new_bills = json_new_bill.results;

        var json_committee_house = JSON.parse(response.data[5]);
        var json_committee_senate = JSON.parse(response.data[6]);
        var json_committee_joint = JSON.parse(response.data[7]);

        $scope.legislators = json_legislator.results;
        $scope.house_legislators = json_legislator_house.results;
        $scope.senate_legislators = json_legislator_senate.results;

        $scope.comms_house = json_committee_house.results;
        $scope.comms_senate = json_committee_senate.results;
        $scope.comms_joint = json_committee_joint.results;

        $scope.party_house = "r.png";
        $scope.party_senate = "d.png";
        $scope.house = "h.png";
        $scope.senate = "s.svg";

    }, function (response) {
        // error code
    });

    $scope.view_details = function (chosen_legislator) {
        $scope.show_bill_tab_fav = false;
        $scope.show_leg_tab_fav = true;
        $scope.chosen_legislator = chosen_legislator;
        var title, firstName, lastName;
        if (chosen_legislator.title)
            title = chosen_legislator.title + ", ";
        else if (chosen_legislator.title === null)
            title = '';

        if (chosen_legislator.last_name)
            lastName = chosen_legislator.last_name + ", ";
        else if (chosen_legislator.last_name === null)
            lastName = '';

        if (chosen_legislator.first_name)
            firstName = chosen_legislator.first_name;
        else if (chosen_legislator.first_name === null)
            firstName = '';

        $scope.chosen_legislator_name = title + lastName + firstName;

        $scope.chosen_legislator_image = "https://theunitedstates.io/images/congress/original/" + chosen_legislator.bioguide_id + ".jpg";

        $scope.chosen_legislator_email = chosen_legislator.oc_email;

        $scope.chosen_legislator_chamber = chosen_legislator.chamber;

        //        202-225-6205
        if (chosen_legislator.phone) {
            var chosen_legislator_phone = chosen_legislator.phone;
            $scope.chosen_legislator_phone = chosen_legislator_phone;
            $scope.phone = chosen_legislator_phone.replace("-", "");
        }


        if (chosen_legislator.office)
            $scope.office = chosen_legislator.office;
        else if (chosen_legislator.office === null)
            $scope.office = "N.A.";

        if (chosen_legislator.state)
            $scope.state = chosen_legislator.state_name;
        else if (chosen_legislator.state === null)
            $scope.state = "N.A";

        if (chosen_legislator.fax)
            $scope.fax = chosen_legislator.fax;

        if (chosen_legislator.party === "R") {
            $scope.chosen_legislator_partyImage = "r.png";
            $scope.chosen_legislator_partyName = "Republican";
        } else if (chosen_legislator.party === "D") {
            $scope.chosen_legislator_partyImage = "d.png";
            $scope.chosen_legislator_partyName = "Democrat";

        }

        if (chosen_legislator.term_start)
            $scope.start = chosen_legislator.term_start;
        else if (chosen_legislator.term_start === null)
            $scope.start = "Not Specified";

        if (chosen_legislator.term_end)
            $scope.end = chosen_legislator.term_end;
        else if (chosen_legislator.term_end === null)
            $scope.end = "Not specified";

        var now = new Date().getTime() / 1000;
        var start = new Date(chosen_legislator.term_start).getTime() / 1000;
        var end = new Date(chosen_legislator.term_end).getTime() / 1000;
        $scope.progress = parseInt((now - start) / (end - start) * 100);

        if (chosen_legislator.birthday)
            $scope.birthday = chosen_legislator.birthday;
        else if (chosen_legislator.birthday === null)
            $scope.birthday = "N.A.";

        if (chosen_legislator.twitter_id) {
            $scope.twitter = "https://twitter.com/" + chosen_legislator.twitter_id;
            $scope.twitter_exists = true;
        }
        if (chosen_legislator.facebook_id) {
            $scope.facebook = "https://www.facebook.com/" + chosen_legislator.facebook_id;
            $scope.facebook_exists = "true";
        }
        if (chosen_legislator.website) {
            $scope.website = chosen_legislator.website;
            $scope.website_exists = "true";
        }


        //GET COMMITTEE AND BILL DATA
        var bioguide_id = chosen_legislator.bioguide_id;
        $http({
            method: 'POST',
            url: 'hw.php',
            data: {
                bioguide_id: bioguide_id
            }
        }).then(function (response) {
            //console.log(response);
            var json_legislator_comm = JSON.parse(response.data[0]);
            var json_legislator_bill = JSON.parse(response.data[1]);
            var leg_bill = [];
            var leg_comm = [];
            var i = 0;
            if (json_legislator_comm.count > 0) {
                i = 0;
                while (i < 5 && i < json_legislator_comm.count) {
                    leg_comm[i] = json_legislator_comm.results[i];
                    i++;
                }
            } else {
                leg_comm[0] = "N.A.";
            }

            if (json_legislator_bill.count > 0) {
                i = 0;
                while (i < 5 && i < json_legislator_bill.count) {
                    leg_bill[i] = json_legislator_bill.results[i];
                    i++;
                }
            } else {
                leg_bill[0] = "N.A.";
            }

            $scope.leg_comms = leg_comm;
            $scope.leg_bills = leg_bill;

        }, function (response) {
            // error code
        });
    };

    $scope.viewdetail_bill = function (bill_detail) {
        $scope.show_bill_tab_fav = true;
        $scope.show_leg_tab_fav = false;
        $scope.chosen_bill = bill_detail;

    }

    $scope.fav_legs = JSON.parse(localStorage.getItem('FavList_Legislator_34853nROU'));
    $scope.fav_comms = JSON.parse(localStorage.getItem('FavList_Committees_34853nROU'));
    $scope.fav_bills = JSON.parse(localStorage.getItem('FavList_Bill_34853nROU'));

    $scope.add_to_fav_legs = function (add_legislator) {

        var a = [];
        var json_string;
        var exists_in_fav = false;
        if (typeof (Storage) !== "undefined") {
            if (localStorage.FavList_Legislator_34853nROU) {

                var fav_leg = JSON.parse(localStorage.getItem('FavList_Legislator_34853nROU'));
                for (var i = 0; i < fav_leg.length; i++) {
                    if (add_legislator.bioguide_id === fav_leg[i].bioguide_id){
                        exists_in_fav = true;
                        $scope.remove_from_fav_legs(add_legislator);
                        break;
                    }
                }
                if (!exists_in_fav) {
                    add_legislator.exists_in_fav = "true";
                    fav_leg.push(add_legislator);
                    localStorage.setItem('FavList_Legislator_34853nROU', JSON.stringify(fav_leg));
                }
                $scope.fav_legs = JSON.parse(localStorage.getItem('FavList_Legislator_34853nROU'));

            } else {

                a.push(add_legislator);
                localStorage.setItem('FavList_Legislator_34853nROU', JSON.stringify(a));
                $scope.fav_legs = JSON.parse(localStorage.getItem('FavList_Legislator_34853nROU'));
            }

        } else {

        }

    };

    $scope.add_to_fav_bills = function (add_bill) {

        var a = [];

        var exists_in_fav = false;
        if (typeof (Storage) !== "undefined") {
            if (localStorage.FavList_Bill_34853nROU) {

                var fav_bill = JSON.parse(localStorage.getItem('FavList_Bill_34853nROU'));
                for (var i = 0; i < fav_bill.length; i++) {
                    if (add_bill.bill_id === fav_bill[i].bill_id) {
                        exists_in_fav = true;
                        $scope.remove_from_fav_bills(add_bill);
                        break;
                    }
                }
                if (!exists_in_fav) {
                    add_bill.exists_in_fav = "true";
                    fav_bill.push(add_bill);
                    localStorage.setItem('FavList_Bill_34853nROU', JSON.stringify(fav_bill));
                }
                $scope.fav_bills = JSON.parse(localStorage.getItem('FavList_Bill_34853nROU'));

            } else {

                a.push(add_bill);
                localStorage.setItem('FavList_Bill_34853nROU', JSON.stringify(a));
                $scope.fav_bills = JSON.parse(localStorage.getItem('FavList_Bill_34853nROU'));
            }

        } else {

        }

    };


    $scope.add_to_fav_comms = function (add_comm) {

        var a = [];
        var json_string;
        var exists_in_fav = false;
        if (typeof (Storage) !== "undefined") {
            if (localStorage.FavList_Committees_34853nROU) {

                var fav_comm = JSON.parse(localStorage.getItem('FavList_Committees_34853nROU'));
                for (var i = 0; i < fav_comm.length; i++) {
                    if (add_comm.committee_id === fav_comm[i].committee_id) {
                        exists_in_fav = true;
                        $scope.remove_from_fav_comms(add_comm);
                        break;
                    }
                }
                if (!exists_in_fav) {
                    add_comm.exists_in_fav = true;
                    fav_comm.push(add_comm);
                    localStorage.setItem('FavList_Committees_34853nROU', JSON.stringify(fav_comm));
                }
                $scope.fav_comms = JSON.parse(localStorage.getItem('FavList_Committees_34853nROU'));

            } else {
                add_comm.exists_in_fav = true;
                a.push(add_comm);
                localStorage.setItem('FavList_Committees_34853nROU', JSON.stringify(a));
                $scope.fav_comms = JSON.parse(localStorage.getItem('FavList_Committees_34853nROU'));
            }

        } else {

        }

    };



    $scope.remove_from_fav_legs = function (rm_legislator) {
        var pos;
        var fav_legs = JSON.parse(localStorage.getItem('FavList_Legislator_34853nROU'));
        for (var i = 0; i < fav_legs.length; i++) {
            if (rm_legislator.bioguide_id === fav_legs[i].bioguide_id)
                pos = i;
        }
        fav_legs.splice(pos, 1);
        for (var pos = 0; pos < $scope.legislators.length; pos++) {
            leg = $scope.legislators[pos];
            if (leg.bioguide_id === rm_legislator.bioguide_id) {
                exists_in_fav = false;
                $scope.legislators[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }
        for (var pos = 0; pos < $scope.house_legislators.length; pos++) {
            leg = $scope.house_legislators[pos];
            if (leg.bioguide_id === rm_legislator.bioguide_id) {
                exists_in_fav = false;
                $scope.house_legislators[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }
         for (var pos = 0; pos < $scope.senate_legislators.length; pos++) {
            leg = $scope.senate_legislators[pos];
            if (leg.bioguide_id === rm_legislator.bioguide_id) {
                exists_in_fav = false;
                $scope.senate_legislators[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }
        
        
        localStorage.setItem('FavList_Legislator_34853nROU', JSON.stringify(fav_legs));
        $scope.fav_legs = JSON.parse(localStorage.getItem('FavList_Legislator_34853nROU'));
    }

    $scope.remove_from_fav_bills = function (rm_bill) {

        var pos;
        var fav_bills = JSON.parse(localStorage.getItem('FavList_Bill_34853nROU'));
        for (var i = 0; i < fav_bills.length; i++) {
            if (rm_bill.bill_id === fav_bills[i].bill_id)
                pos = i;
        }
        fav_bills.splice(pos, 1);

        for (var pos = 0; pos < $scope.active_bills.length; pos++) {
            bill = $scope.active_bills[pos];
            if (bill.bill_id === rm_bill.bill_id) {
                exists_in_fav = false;
                $scope.active_bills[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }
        for (var pos = 0; pos < $scope.new_bills.length; pos++) {
            bill = $scope.new_bills[pos];
            if (bill.bill_id === rm_bill.bill_id) {
                exists_in_fav = false;
                $scope.new_bills[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }

        localStorage.setItem('FavList_Bill_34853nROU', JSON.stringify(fav_bills));
        $scope.fav_bills = JSON.parse(localStorage.getItem('FavList_Bill_34853nROU'));
    }

    $scope.remove_from_fav_comms = function (rm_comm) {

        var pos;
        var fav_committees = JSON.parse(localStorage.getItem('FavList_Committees_34853nROU'));
        for (var i = 0; i < fav_committees.length; i++) {
            if (rm_comm.committee_id === fav_committees[i].committee_id)
                pos = i;
        }
        fav_committees.splice(pos, 1);
        for (var pos = 0; pos < $scope.comms_house.length; pos++) {
            comm = $scope.comms_house[pos];
            if (comm.committee_id === rm_comm.committee_id) {
                exists_in_fav = false;
                $scope.comms_house[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }
        for (var pos = 0; pos < $scope.comms_senate.length; pos++) {
            comm = $scope.comms_senate[pos];
            if (comm.committee_id === rm_comm.committee_id) {
                exists_in_fav = false;
                $scope.comms_senate[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }
        for (var pos = 0; pos < $scope.comms_joint.length; pos++) {
            comm = $scope.comms_joint[pos];
            if (comm.committee_id === rm_comm.committee_id) {
                exists_in_fav = false;
                $scope.comms_joint[pos].exists_in_fav = exists_in_fav;
                break;
            }
        }
        localStorage.setItem('FavList_Committees_34853nROU', JSON.stringify(fav_committees));
        $scope.fav_comms = JSON.parse(localStorage.getItem('FavList_Committees_34853nROU'));
    }


}); //End of Main Controller

app.filter('capitalize', function () {
    return function (s) {
        return (angular.isString(s) && s.length > 0) ? s[0].toUpperCase() + s.substr(1).toLowerCase() : s;
    }
});

app.filter('trustAsResourceUrl', function ($sce) {
    return function (val) {
        return $sce.trustAsResourceUrl(val);
    };
});

/*
  $scope.currentPage = 1;
  $scope.pageSize = 10;
  $scope.meals = [];

  var dishes = [
    'noodles',
    'sausage',
    'beans on toast',
    'cheeseburger',
    'battered mars bar',
    'crisp butty',
    'yorkshire pudding',
    'wiener schnitzel',
    'sauerkraut mit ei',
    'salad',
    'onion soup',
    'bak choi',
    'avacado maki'
  ];
  var sides = [
    'with chips',
    'a la king',
    'drizzled with cheese sauce',
    'with a side salad',
    'on toast',
    'with ketchup',
    'on a bed of cabbage',
    'wrapped in streaky bacon',
    'on a stick with cheese',
    'in pitta bread'
  ];
  for (var i = 1; i <= 100; i++) {
    var dish = dishes[Math.floor(Math.random() * dishes.length)];
    var side = sides[Math.floor(Math.random() * sides.length)];
    $scope.meals.push('meal ' + i + ': ' + dish + ' ' + side);
  }
  
  $scope.pageChangeHandler = function(num) {
      console.log('meals page changed to ' + num);
  };*/